import '../CSS/navbar.css';

function Navbar() {
  return (
    <nav className="app-navbar">
      <div className="app-title">Farmer's POS</div>
    </nav>
  );
}

export default Navbar;
