function Report() {
  return <h2>Report Page</h2>;
}

export default Report;
