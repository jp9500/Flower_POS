
import { useState } from "react";
import { toast } from "react-toastify/unstyled";
import { useNavigate } from "react-router-dom";


function Ipconfig() {
  const [ip, setIp] = useState("");
   const navigate = useNavigate();

  const handleSave = () => {
    if (ip.trim() !== "") {
      localStorage.setItem("ipconfig", ip);
      toast.success("IP saved: " + ip);
      navigate('/login');
    } else {
      toast.error("Please enter a valid IP");
    }
  };

  return (
    <div>
      <h1>IP Configuration Page</h1>
      <input
        className="custom"
        value={ip}
        onChange={(e) => setIp(e.target.value)} // track input value
        placeholder="Enter IP address"
      />
      <button className="btn" onClick={handleSave}>
        Save
      </button>
    </div>
  );
}

export default Ipconfig;